import socket, sys, os, threading, tkinter as tk
from utils import write_log, CONFIG
from ai_guard import AIGuard
from honeypot import HoneyPot
def ensure_singleton(port):
    s=socket.socket()
    try: s.bind(("127.0.0.1", port)); return s
    except: print("Already running"); sys.exit(0)
s = ensure_singleton(CONFIG.get("singleton_port",52345))
class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title(CONFIG.get("app_name","CyberDefense Pro Final")); self.geometry("900x600")
        self.guard=None; self.stop_event=threading.Event()
        tk.Button(self,text="Run AI Guard", command=self.run_guard).pack()
        tk.Button(self,text="Stop AI Guard", command=self.stop_guard).pack()
        self.log=tk.Text(self); self.log.pack(fill="both",expand=True)
    def ui_log(self,lvl,msg):
        self.log.insert("end", f"[{lvl}] {msg}\\n"); write_log("GUI", msg, lvl)
    def run_guard(self):
        if self.guard and self.guard.is_alive(): return
        self.stop_event.clear()
        self.guard=AIGuard(ui=self.ui_log, stop_event=self.stop_event); self.guard.start()
        if CONFIG.get("security",{}).get("allow_honeypot",False):
            self.honey = HoneyPot(ui=self.ui_log); self.honey.start()
    def stop_guard(self):
        if self.guard: self.stop_event.set(); self.ui_log("INFO","AI Guard stopped")
app = App(); app.mainloop(); s.close()
