import os, time, threading
from utils import write_log
class HoneyPot(threading.Thread):
    daemon=True
    def __init__(self, base_dir=None, files=None, interval=5, ui=None):
        super().__init__(); self.base_dir = base_dir or os.path.join(os.path.expanduser("~"), "HoneyFiles"); self.files = files or ["passwords.txt"]; self.interval=interval; self.ui=ui; os.makedirs(self.base_dir,exist_ok=True); self._mt={} 
        self._ensure()
    def _ensure(self):
        for fn in self.files:
            p=os.path.join(self.base_dir,fn)
            if not os.path.exists(p):
                with open(p,"w",encoding="utf-8") as f: f.write("honey")
            self._mt[fn]=os.path.getmtime(p)
    def run(self):
        while True:
            for fn in self.files:
                p=os.path.join(self.base_dir,fn)
                try:
                    if os.path.exists(p):
                        m=os.path.getmtime(p)
                        if m!=self._mt.get(fn):
                            write_log("HONEY", f"access {p}", "ALERT")
                            if self.ui: self.ui("ALERT", f"Honey accessed {p}")
                        self._mt[fn]=m
                except: pass
            time.sleep(self.interval)
