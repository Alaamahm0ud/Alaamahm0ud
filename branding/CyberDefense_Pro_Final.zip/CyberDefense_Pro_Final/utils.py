import os, json, hashlib, time, smtplib, socket
from datetime import datetime
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")
def _now(): return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
def load_config():
    try:
        with open(CONFIG_PATH,"r",encoding="utf-8") as f: return json.load(f)
    except: return {}
CONFIG = load_config()
def write_log(cat,msg,sev="INFO"):
    p = os.path.join(os.path.dirname(__file__),"logs",f"cyberdefense_{time.strftime('%Y%m%d')}.log")
    line = f"[{_now()}] [{cat}] [{sev}] {msg}\\n"
    with open(p,"a",encoding="utf-8") as f: f.write(line)
    return p
def hash_file(path, algo="sha256"):
    h = hashlib.new(algo)
    with open(path,"rb") as f:
        for chunk in iter(lambda: f.read(8192), b""): h.update(chunk)
    return h.hexdigest()
def send_email(smtp_server, port, sender, password, recipient, subject, body):
    try:
        import ssl
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender, password)
            msg = f"Subject: {subject}\\n\\n{body}"
            server.sendmail(sender, recipient, msg)
        return True
    except Exception as e:
        write_log("EMAIL", f"Failed: {e}", "ERROR")
        return False
