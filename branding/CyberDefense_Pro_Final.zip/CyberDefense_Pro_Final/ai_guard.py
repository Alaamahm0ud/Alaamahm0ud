import threading, time, psutil
from utils import write_log, CONFIG
class AIGuard(threading.Thread):
    daemon=True
    def __init__(self, ui=None, stop_event=None):
        super().__init__(); self.ui=ui; self.stop_event = stop_event or threading.Event()
    def push(self, lvl,msg):
        write_log("AI", msg, lvl); 
        if self.ui: self.ui(lvl,msg)
    def run(self):
        while not self.stop_event.is_set():
            cpu = psutil.cpu_percent(interval=0.2); mem = psutil.virtual_memory().percent
            if cpu>85: self.push("ALERT", f"High CPU {cpu}%")
            if mem>90: self.push("ALERT", f"High Memory {mem}%")
            time.sleep(CONFIG.get("scan_interval",10))
