CyberDefense Pro Final - Advanced defensive project.
Run python main.py after installing requirements.