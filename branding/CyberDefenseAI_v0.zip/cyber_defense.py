
import tkinter as tk
from tkinter import messagebox
import psutil
import os
import time

APP_NAME = "CyberDefenseAI v0"
LOG_FILE = "logs.txt"

def log_event(message):
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{ts}] {message}\n")

def start_defense():
    # Placeholder for real defense start (firewall rules, monitors...)
    log_event("تشغيل الحماية الكاملة")
    messagebox.showinfo("الحماية", "✅ تم تشغيل الحماية الكاملة")

def stop_defense():
    # Placeholder for stopping extra defenses
    log_event("إيقاف الحماية الإضافية")
    messagebox.showwarning("الحماية", "⛔ تم إيقاف الحماية الإضافية")

def show_processes():
    processes = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            name = proc.info['name'] or 'unknown'
            pid = proc.info['pid']
            processes.append(f"{name} (PID: {pid})")
        except Exception:
            continue
    log_event("عرض العمليات النشطة")
    chunk = "\n".join(processes[:40]) or "لا توجد عمليات للعرض."
    messagebox.showinfo("العمليات النشطة", chunk)

def ensure_log():
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write(f"== {APP_NAME} Logs ==\n")

def main():
    ensure_log()
    root = tk.Tk()
    root.title(APP_NAME)
    root.geometry("420x300")

    tk.Button(root, text="تشغيل الحماية الكاملة", command=start_defense, bg="green", fg="white", height=2).pack(pady=10, fill="x", padx=20)
    tk.Button(root, text="إيقاف الحماية الإضافية", command=stop_defense, bg="red", fg="white", height=2).pack(pady=10, fill="x", padx=20)
    tk.Button(root, text="عرض حالة النظام (عمليات)", command=show_processes, bg="blue", fg="white", height=2).pack(pady=10, fill="x", padx=20)

    root.mainloop()

if __name__ == "__main__":
    main()
