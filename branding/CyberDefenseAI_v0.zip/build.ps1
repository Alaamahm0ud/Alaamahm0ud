
# ----- Build script for Windows -----
# Usage (PowerShell as Administrator not required):
# 1) python -m pip install -r requirements.txt
# 2) python -m pip install pyinstaller
# 3) .\build.ps1

$ErrorActionPreference = "Stop"

# Clean dist/build if exist
if (Test-Path -Path ".\dist") { Remove-Item -Recurse -Force ".\dist" }
if (Test-Path -Path ".\build") { Remove-Item -Recurse -Force ".\build" }

# Build one-file, windowed EXE
pyinstaller --noconsole --onefile --name CyberDefenseAI --clean cyber_defense.py

Write-Host ""
Write-Host "Build finished. EXE path:" -ForegroundColor Green
Write-Host (Resolve-Path ".\dist\CyberDefenseAI.exe")
