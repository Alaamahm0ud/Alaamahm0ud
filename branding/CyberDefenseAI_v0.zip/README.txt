
# CyberDefenseAI v0 — Prototype GUI
This is the first operational prototype (Windows-friendly). It shows a simple GUI with three buttons:
- Start Defense (placeholder)
- Stop Extra Defense (placeholder)
- Show Processes (lists active processes; logs events to `logs.txt`)

## How to run (Python)
1) Install Python 3.9+
2) Open PowerShell in this folder and run:
   python -m pip install -r requirements.txt
   python .\cyber_defense.py

## How to build EXE (PyInstaller)
1) Install requirements and pyinstaller:
   python -m pip install -r requirements.txt
   python -m pip install pyinstaller
2) Build:
   .\build.ps1
3) The executable will be created at: .\dist\CyberDefenseAI.exe

## Notes
- This is just a starting point. We'll expand it with firewall control, network scanning, AI anomaly detection, and reporting.
- All user actions are logged in `logs.txt`.
